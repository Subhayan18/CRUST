#' Probabilistic quotient normalization of WES data
#'
#' A normalization technique described in \emph{Dieterle, et al. (2006)} applied on the cancer cell fraction (CCF) to rescale variant allele frequencies (VAF).
#' This method is particularly suggested if the quality of samples vary more than 0.1 all accross the board.
#' @param x A \code{dataframe} of \emph{WES} data with first column as sample IDs of corresponding variants
#' @param vaf The column number of \code{x} that includes VAFs
#' @param CCF The column number of \code{x} that includes CCFs
#' @return A \code{dataframe} with all the elements of \code{x} with the new estimated VAFs in the column \emph{scaled.vaf} and an additional column \emph{unscaled.vaf} that includes the original VAFs
#' @examples
#' \donttest{pqn.dat<-CS.scale(test.dat,vaf=2,CCF=3)
#' hist(pqn.dat$scaled.vaf)}
#' @export
CS.scale<- function(x,vaf,CCF) {
  x$ID<-1:nrow(x)
  train<-x[x[[CCF]] == max(x[[CCF]]),]
  test<-setdiff(x,train)
  N.pqn<-normalization(Xtrain=test[,c(vaf,CCF)],Xtest=NULL, method = "pqn",ref=train[,c(vaf,CCF)])
  X.pqn<-rbind(train,test)
  X.pqn$pqn_scaled_vaf<-c(train[[vaf]],N.pqn$newXtrain[,1])
  X.pqn<-X.pqn[order(X.pqn$ID),]
  X.pqn<-subset(X.pqn, select=-c(ID))
  colnames(X.pqn)[vaf]<-'unscaled.vaf'
  X.pqn<-arrange.vars(X.pqn, c("pqn_scaled_vaf"=2))
  colnames(X.pqn)[2]<-'scaled.vaf'
  return(X.pqn)
}
