#' Random number generated WES data for eight hypothetical samples
#'
#' Data generated with varying random normal probabilities. ideal chromosomal segmentation
#' profile is assumed resulting in three separate distinct clouds of clones and sub-clones.
#'
#' @docType data
#'
#' @usage data(test.dat)
#'
#' @format An object of class \code{"dataframe"}
#'
#' @return \code{sample} is column of IDs corresponding to 8 distinct samples.
#' @return \code{vaf} denotes the variant allele frequencies of each variant (see \code{annotation}).
#' @return \code{CCF} are the cancer cell fractions of each sample.
#' @return \code{annotation} indicates corresponding variants for which observations are notes in each row. Variants can be shared among
#' several samples as well as be private mutation.
#'
#' @keywords datasets
#'
#' @examples
#' \donttest{data(test.dat)
#' table(test.dat$CCF)
#' table(test.dat$annotation)
#' hist(test.dat$vaf)}
"test.dat"
