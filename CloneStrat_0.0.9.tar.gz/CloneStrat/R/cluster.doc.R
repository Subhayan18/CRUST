#' Clonal deconvolution
#'
#' Clone / Sub-clone decomposition of WES data
#' @param x A \code{dataframe} with first column as sample IDs and second column as variant allele frequencies
#' of corresponding variants obtained from WES
#' @return A list of 6 objects is retuned that includes all the summary statistics, diagnositics and the predictions.
#' @return \code{cluster.diagnostics} is an object of \code{S3} class which includes clustering diagnostics from the model-based clustering.
#' @return \code{fitted cluster} is a clustering object of class \code{S3}. This will be the fitted clustering either user driven/
#' system predicted or user over-ridden.
#' @return \code{predicted.data} is necessarily an extension to the input data \code{x} with the addition of the predicted clone and sub-clone
#' status of each variant for corresponding samples.
#' @return \code{optimum.clusters} is the system predicted optimum number of clusters that was either fitted or suggested to the user.
#' The detailed statistics used for this decision can be found in \code{cluster.diagnostics$bic}
#' @return \code{diagnosed.dunn} is the Dunn index for the suggested cluster.
#' @return \code{fitted.dunn} is the Dunn index for the fitted cluster.
#' @examples
#' \donttest{cluster.doc(test.dat)}
#' @export
cluster.doc <- function (x){
if (missing(x)) stop ("missing x")
  i.1 <- Init.input(x[,1:2])
  #tmp.0<-i.1$r+i.1$m
  tmp.0<-i.1$r+i.1$m
  tmp.1<-min(tmp.0,2*i.1$h2)
  tmp.2<-tmp.1+9
  d_clust <- Mclust(as.matrix(x[,2]), G=tmp.1:tmp.2) #Hard saving d_clust

  #Optimum number of clusters
  m.best <- dim(d_clust$z)[2]

  #Dunn index for suggested clustering
  df<-scale(x[,2])

  cat("Predicted optimal number of clusters:", m.best, "\n")
  #m.tot = 2*m.best

  #K means clustering on optimum k
  kmeansM_ex1<-kmeans(as.matrix(x[,2]),centers=m.best)
  diagnosed.clust.stats <- cluster.stats(d = dist(df), kmeansM_ex1$cluster)
  diagnosed.dunn <- as.numeric(diagnosed.clust.stats$dunn)
  fitted.dunn <- diagnosed.dunn

  if (m.best == tmp.0) {
    print("Congratulations! Your guess was correct")
    cat("\n The centroids of the clusters are: \n")
    cat(kmeansM_ex1$centers)
    cat("\n\n")
    if (dim(table(d_clust$classification)) < m.best) {
      warning("fitted number of clusters is less than that predicted. You may want to choose less clone-subclone clouds")
    }
  } else {
    cat ("Liar, liar, pants on fire!\n")
    cat ("The number of sub/clonal clouds differ from your guess\n")
    h <- (readline("Do you want to see my suggestion? (yes/no): \n"))
    if (h == "yes") {
      #q = m.best-i.1$r
      if((m.best %% 2) == 0) {
        q = m.best/2
        cat(paste0("\n I suggest ", q, " clone(s) and ", q, " subclone(s) /n/n"))
      } else {
        q = m.best-i.1$t.0
        cat(paste0("\n I suggest ", i.1$t.0, " clone(s) and ", q, " subclone(s) /n/n"))
      }

      #cat(paste0("\n I suggest ", i.1$r, " clone(s) and ", q, " subclone(s)"))

      cat("\n The centroids of the clusters are: \n")
      cat(kmeansM_ex1$centers)
      cat("\n\n")
    }
    else{
      kmeansM_ex1<-kmeans(as.matrix(x[,2]),centers=tmp.0)

      #Dunn index for fitted clustering
      fitted.clust.stats <- cluster.stats(d = dist(df), kmeansM_ex1$cluster)
      fitted.dunn <- as.numeric(fitted.clust.stats$dunn)

      cat("Very well. Suit yourself!")
      #cat(paste0("\n You have chosen ", i.1$r, " clone(s) and ", q, " subclone(s), hence there will be ", tmp.0, " clusters"))
      cat("\n\n The centroids of the clusters are: \n")
      cat(kmeansM_ex1$centers)
      cat("\n\n Dunn index for suggested clusters:")
      cat(diagnosed.dunn)
      cat("\n\n Dunn index for fitted clusters:")
      cat(fitted.dunn)
      cat("\n\n Higher Dunn index indicates better fit")
      cat("\n\n Higher BIC also indicates better fit \n\n")
      cat("\n\n")
      if (dim(table(d_clust$classification)) < m.best) {
        cat("\n\n")
        warning("fitted number of clusters is less than that predicted. You may want to choose less clone-subclone clouds")
      }
      plot(mclustBIC(as.matrix(x[,2])))
    }
  }
  if(min(dist(kmeansM_ex1$centers))<0.05){
    warning("centroids of clonal and sub-clonal clusters are too close to comfort (+/- 0.05)! Interprete the results with caution.")
  }
  tmp.3<-rank(kmeansM_ex1$centers)
  tmp.4<-as.numeric(tmp.3[as.factor(kmeansM_ex1$cluster)])
  max.tmp.4<-max(tmp.4)
  if (tmp.0 %% 2 == 0) {
    x$'predicted clonal structure'<- noquote(unlist(lapply(tmp.4 %% 2 == 0, ifelse, "Clone", "Sub-clone")))
  } else {
    x$'predicted clonal structure'<- noquote(unlist(lapply(tmp.4 %% 2 == 0 | tmp.4 == max.tmp.4, ifelse, "Clone", "Sub-clone")))
  }
  #Print the clones and sub-clones
  x.plot<-x[,c(1,2,ncol(x))]
  colnames(x.plot)<-c("sample","vaf","pred")
  t<-function(){
    g<-ggplot(x.plot,aes(x=sample,y=vaf))+
      geom_point(aes(color=factor(pred)))+
      labs(title="Scatter plot of VAF values",
           y="Variant allele frequency",
           color="Predicted clonal structure")+
      ylim(0,max(x.plot$vaf)+0.1)
    print(g)
  }

  t()
  par(ask=TRUE)
  suppressWarnings(plot(d_clust[['BIC']]))
  par(ask=FALSE)

  invisible(list(cluster.diagnostic=d_clust, fitted.cluster=kmeansM_ex1, predicted.data = x,
                 optimum.clusters=m.best,diagnosed.dunn=diagnosed.dunn, fitted.dunn=fitted.dunn))
}
