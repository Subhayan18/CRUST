plot.bic<-function(tmp){
if (is.null(dim(tmp)) == TRUE){
  tmp<-as.data.frame(tmp$profile)
  colnames(tmp)<-'SIN'
  cluster<-tmp$cluster<-as.numeric(rownames(tmp))

  ggplot(data=tmp, aes(x=cluster, y=SIN, color=SIN))+
    geom_point(size=4,, show.legend = F)+
    theme_minimal()+
    geom_line(size=1.5, show.legend = F)+ 
    labs(title="Changes in Smin as number of clusters increases",
         y="Smin statistics")+
    scale_x_continuous(breaks=cluster)
}
else{
  cluster<-as.numeric(rep(rownames(tmp),2))
  BIC<-c(tmp[,1],tmp[,2])
  group<-c(rep('Expectation',nrow(tmp)),rep('Variance',nrow(tmp)))
  tmp<-as.data.frame(BIC)
  tmp$'Cluster Numbers'<-cluster
  tmp$metric<-group

  ggplot(data=tmp, aes(x=cluster, y=BIC, group=metric, color=metric, shape=metric, linetype=metric))+
    geom_point(size=4)+
    guides(alpha = FALSE)+
    scale_color_brewer(palette="Paired")+
    theme_minimal()+
    geom_line(size=1.5, show.legend = F)+
    labs(title="Changes in BIC as number of clusters increases",
       y="Bayesian Information Criteria (BIC)",
       metric="Evaluation Metric")+
    scale_x_continuous(breaks=cluster)
  }
}
