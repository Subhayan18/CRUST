#' Copynumber estimation
#'
#' Allelic segmentations are estimated for one sample at a time with unfiltered sequencing calls using the package \code{sequenza}.
#'
#' @param x A \code{vcfR} object of the WES calls.
#' @param tumor.sample a \code{character} denoting the \emph{name} of the sample (only one sample).
#' The sample names can be queried from \code{x}.
#' @param normal.sample a \code{character} denoting the \emph{name} of the normal tissue sample against which the tumor sample is to be analyzed.
#' @param DP a \code{character} denoting \emph{ID} for total read depth (empirical or approx) to be extracted from the \emph{FORMAT} field of \code{x}
#' @param AD a \code{character} deoning \emph{ID} for depth of the reference allele.
#' @param AF an optional \code{character} deoning \emph{ID} for allele fraction of the reference allele.
#' This is often separately present in the VCF file. Default is \code{NULL}.
#' @param file.name an optional \code{character} to define output file name. Default is \emph{tumor.sample}.
#'
#' @return A transformed \code{dataframe} usable in \emph{CloneStrat} that represents data on all variants in the .vcf file. It returns summaries
#' on the variants with the collumn \emph{CN.profile} depicting the estimated allelic segmentations.
#'
#' @details The function writes a \emph{.txt} data in working directory with the name defined in \code{file.name} used by \emph{sequenza}.
#' The output file written can be used in conjunction with post variants call sequence file. These can be merged and used for surther analysis
#' with \code{\link{cluster.doc}} or \code{\link{seqn.scale}}
#'
#' @examples \donttest{CopySeg(x = sample.vcf, tumor.sample = c("tumor"),
#' normal.sample = "normal", DP = 'DP', AD = 'AD', AF = 'AF', file.name = 'temp')}
#' @export
CopySeg<-function(x, tumor.sample, normal.sample, DP, AD, AF, file.name){

  if (missing(x) | class(x)[1] != 'vcfR')
    stop ("missing or incorrect entry for x")
  if (missing(tumor.sample) | class(tumor.sample) != 'character')
    stop ("missing or incorrect entry for tumor.sample")
  if (missing(normal.sample) | class(normal.sample) != 'character')
    stop ("missing or incorrect entry for normal.sample")
  if (missing(DP) | class(DP) != 'character')
    stop ("missing or incorrect entry for DP")
  if (missing(AD) | class(AD) != 'character')
    stop ("missing or incorrect entry for AD")
  if (missing(file.name)) {file.name=tumor.sample}
  if (!missing(file.name) & class(file.name) != 'character')
    stop ("incorrect entry for file.name")

  dp <- as.data.frame(extract.gt(x,  element = DP, as.numeric = TRUE))
  ad <-as.data.frame(extract.gt(x,  element = AD, as.numeric = TRUE))

  chromosome<-noquote(getCHROM(x))
  position<-as.numeric(getPOS(x))
  base.ref<-noquote(getREF(x))

  depth.normal<-dp[[normal.sample]]
  depth.tumor<-dp[[tumor.sample[1]]]
  depth.ratio<-round(depth.tumor/depth.normal,3)

  tumor.ad<-ad[[tumor.sample[1]]]
  tumor.bd<-depth.tumor-tumor.ad

  Bf<-round(tumor.bd/depth.tumor,3)

  if(!missing(AF)){
    af<-as.data.frame(extract.gt(x,  element = AF, as.numeric = TRUE))
    Af<-round(exp(-af[[tumor.sample[1]]]),3)} else{
      Af<-1-Bf
    }

  zygosity.normal<-ifelse(Bf < 0.9 & Bf > 0.1, 'het', 'hom')

  tumor<-dplyr::as_tibble(cbind(chromosome, position, base.ref, depth.normal,
                                depth.tumor, depth.ratio, Af, Bf, zygosity.normal))

  GC$pos<-paste0(GC$chr,":",GC$interval1,"-",GC$interval2)
  GC<-GC[,c(5,4)]
  window<-function(x){options(scipen=999);ceiling(x/10^4)*10^4}
  interval.1<-window(position)
  tumor$pos<-paste0('chr',chromosome,':',1+interval.1-10^4,"-",interval.1)
  tumor<-dplyr::left_join(tumor,GC,by='pos')

  tumor$GC.percent<-ceiling(tumor$GC*100)
  tumor<-subset(tumor, select=-c(pos,GC))

  tumor$good.reads<-ceiling(0.95*as.numeric(tumor$depth.tumor))
  tumor$AB.normal<-'.'
  tumor$AB.tumor<-'.'
  tumor$tumor.strand<-'.'

  tumor<-subset(tumor,tumor$chromosome != 'Y')
  tumor<-subset(tumor,tumor$depth.normal != '0')
  if(!missing(file.name)){
  name.txt<-paste0("sqz.",file.name,".txt")} else{
    name.txt<-paste0("sqz.",tumor.sample,".txt")
  }

  print("Writing the sequenza data file")
  write.table(tumor,name.txt,row.names=F,quote=F,sep="\t")
  if (nrow(tumor) > 10000) {print("Adequate variants present")}
  else {stop("Inadequate (less than 10k) variants present in the file! Please make sure the constitutional reads are present.")}

  test<-sequenza.extract(name.txt, verbose=FALSE)

  print("Evaluating summary statistics")
  CP <- sequenza.fit(test)
  confint <- get.ci(CP)
  seqz.data <- read.seqz(name.txt)
  print("Evaluating mode of allelic composition")
  test.CN<-as_tibble(baf.bayes(seqz.data$Bf, seqz.data$depth.ratio, confint$max.cellularity, confint$max.ploidy,avg.depth.ratio = 1))
  tumor$CN.profile<-paste(test.CN$A,"+",test.CN$B)
  #tumor$CN.profile <- na_if(tumor$CN.profile == "0 + 0")
  tumor<-tumor[,-c(12,13,14)]
  print("Done")
  return(tumor)
}
