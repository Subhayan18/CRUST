#' @import dplyr
#' @import ggplot2
#' @import mclust
#' @import fpc
#' @import KODAMA
#' @import sequenza
#' @import vcfR
#' @import bootcluster
#' @import factoextra
#' @import FactoMineR
#' @import rlang
#' @import RcppArmadillo
#' @importFrom graphics par
#' @importFrom stats dist
#' @importFrom stats kmeans
#' @importFrom stats na.omit
#' @importFrom stats pchisq
#' @importFrom utils write.table
utils::globalVariables(c("pos","SIN","metric"))
NULL
