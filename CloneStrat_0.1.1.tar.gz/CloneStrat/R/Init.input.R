Init.input <- function(x.1){
  h <- (readline("What is the suspected chromosomal segmentation profile of the sample: \n
  (WARNING! Include spaces between numbers and '+')\n
  example : 1 + 2, 2 + 2, 19 + 57 etc.\n"))
  h1<-unlist(strsplit(h," ")[1])[1]
  h2<-unlist(strsplit(h," ")[1])[3]
  h1 <- as.numeric(h1)
  h2 <- as.numeric(h2)
  ##Check how the sample-wise distribution looks
  colnames(x.1)<-c("sample","vaf")
  g<-ggplot(x.1,aes(x=sample,y=vaf))+
    geom_point(aes(color=factor(sample)))+
    labs(title="Scatter plot of VAF values",
         y="Variant allele frequency",
         color="samples")+
    ylim(0,max(x.1$vaf)+0.1)
  cat("  Plotting the clonal smear of VAFs.
  Please guesstimate the following for all samples judging by the plot \n")
  print(g)
  r <- (readline("How many clonal VAF clouds do you think are present: \n"))
  r <- as.numeric(r)
  m <- (readline("How many sub-clonal VAF clouds do you think are present: \n"))
  m <- as.numeric(m)
  list(h1=h1, h2=h2, r=r, m=m)
}
