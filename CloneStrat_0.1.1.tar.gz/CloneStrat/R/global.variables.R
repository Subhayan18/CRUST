globalVariables(c("ID",".","vaf","pred","marker"))
